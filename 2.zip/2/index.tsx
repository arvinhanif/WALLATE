
// Vanilla JS Implementation of Warrick Wallet
const STORAGE_KEY = 'warrick_wallet_data_v3';
const PROFILE_KEY = 'warrick_wallet_profile_v3';

// --- STATE MANAGEMENT ---
let state = {
    profile: JSON.parse(localStorage.getItem(PROFILE_KEY)) || {
        name: 'User',
        currency: '৳',
        role: 'USER'
    },
    transactions: JSON.parse(localStorage.getItem(STORAGE_KEY)) || [],
    tempName: ''
};

function saveState() {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(state.profile));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.transactions));
    render();
}

// --- RENDERING ENGINE ---
function render() {
    // 1. Update Profile UI
    document.getElementById('profile-display-name').textContent = state.profile.name;
    document.getElementById('profile-role').textContent = state.profile.role;
    // Cast to HTMLImageElement to access src property
    (document.getElementById('header-avatar') as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${state.profile.name}`;
    (document.getElementById('modal-avatar') as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${state.tempName || state.profile.name}`;
    
    // 2. Calculate Stats
    const income = state.transactions.filter(t => t.type === 'INCOME').reduce((a, b) => a + b.amount, 0);
    const expenses = state.transactions.filter(t => t.type === 'EXPENSE').reduce((a, b) => a + b.amount, 0);
    const balance = income - expenses;

    // 3. Render Stats Cards
    const statsGrid = document.getElementById('stats-grid');
    statsGrid.innerHTML = `
        ${renderStatCard('Total Balance', balance, 'balance')}
        ${renderStatCard('Income', income, 'income')}
        ${renderStatCard('Expenses', expenses, 'expense')}
    `;

    // 4. Render Form
    const formContainer = document.getElementById('transaction-form-container');
    if (state.profile.role === 'ADMIN') {
        formContainer.innerHTML = `
            <form id="tx-form" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <input required id="tx-desc" type="text" placeholder="Memo / Description" class="w-full px-6 py-4 rounded-2xl bg-white border border-slate-100 outline-none font-semibold">
                <input required id="tx-amount" type="number" step="0.01" placeholder="0.00" class="w-full px-6 py-4 rounded-2xl bg-white border border-slate-100 outline-none font-semibold">
                <select id="tx-type" class="w-full px-6 py-4 rounded-2xl bg-white border border-slate-100 outline-none font-semibold cursor-pointer">
                    <option value="EXPENSE">Expense Out</option>
                    <option value="INCOME">Income In</option>
                </select>
                <button type="submit" class="bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-700 ios-button shadow-lg uppercase tracking-widest">Sync Entry</button>
            </form>
        `;
        document.getElementById('tx-form').addEventListener('submit', handleFormSubmit);
    } else {
        formContainer.innerHTML = `
            <div class="py-12 text-center bg-slate-50/50 rounded-3xl border-2 border-dashed border-slate-200">
                <p class="text-slate-400 text-sm font-bold uppercase tracking-widest italic">Authorization Required to Sync Data</p>
            </div>
        `;
    }

    // 5. Render Transaction List
    const listContainer = document.getElementById('transaction-list-container');
    listContainer.innerHTML = `
        <div class="p-8 border-b border-white/40 flex justify-between items-center bg-white/30">
            <div>
                <h3 class="text-xl font-extrabold text-slate-900 tracking-tight">Recent Activity</h3>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Live Transaction Stream</p>
            </div>
            <span class="text-[10px] font-black bg-white/80 border border-white px-3 py-1 rounded-full uppercase shadow-sm">${state.transactions.length} Logs</span>
        </div>
        <div class="max-h-[500px] overflow-y-auto px-4 pb-4 custom-scroll">
            ${state.transactions.length === 0 ? `
                <div class="py-20 text-center">
                    <p class="text-slate-300 font-bold uppercase text-[11px] tracking-widest">No Activity Records</p>
                </div>
            ` : `
                <div class="space-y-2 mt-4">
                    ${state.transactions.map(t => renderTransactionRow(t)).join('')}
                </div>
            `}
        </div>
    `;

    // 6. Update Modals Action
    const authContainer = document.getElementById('auth-action-container');
    if (state.profile.role === 'USER') {
        authContainer.innerHTML = `<button id="btn-request-admin" class="w-full py-6 border-2 border-dashed border-blue-200 bg-blue-50/40 text-blue-600 text-[12px] font-black rounded-[2rem] uppercase tracking-[0.2em] ios-button">Request Admin Clearance</button>`;
        document.getElementById('btn-request-admin').addEventListener('click', () => { closeProfile(); openLogin(); });
    } else {
        authContainer.innerHTML = `<button id="btn-terminate-admin" class="w-full py-6 bg-rose-50 text-rose-600 text-[12px] font-black rounded-[2rem] uppercase tracking-[0.2em] ios-button border border-rose-100">Terminate Admin Protocol</button>`;
        document.getElementById('btn-terminate-admin').addEventListener('click', handleLogout);
    }

    // Attach row delete listeners
    document.querySelectorAll('.btn-delete-tx').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            state.transactions = state.transactions.filter(t => t.id !== id);
            saveState();
        });
    });

    // Update Currency Buttons
    document.querySelectorAll('.currency-btn').forEach(btn => {
        const cur = btn.getAttribute('data-currency');
        if (cur === state.profile.currency) {
            btn.className = "currency-btn py-8 rounded-[2rem] font-black text-3xl transition-all ios-button bg-blue-600 text-white shadow-2xl scale-105";
        } else {
            btn.className = "currency-btn py-8 rounded-[2rem] font-black text-3xl transition-all ios-button bg-slate-50 text-slate-400 border border-slate-100";
        }
    });
}

function renderStatCard(label, amount, type) {
    const isBalance = type === 'balance';
    const colorClass = type === 'income' ? 'text-emerald-600' : (type === 'expense' ? 'text-rose-600' : 'text-white');
    const bgClass = isBalance ? 'bg-gradient-to-br from-blue-600 to-blue-700 shadow-blue-500/20' : 'bg-white shadow-slate-100';
    const labelColor = isBalance ? 'text-blue-100' : 'text-slate-400';
    
    return `
        <div class="ios-widget p-7 ios-glass ${bgClass} flex flex-col justify-between h-40 shadow-2xl">
            <div class="flex justify-between items-start">
                <p class="text-[11px] font-black uppercase tracking-widest ${labelColor}">${label}</p>
            </div>
            <h2 class="text-3xl font-extrabold tabular-nums tracking-tighter ${colorClass}">
                <span class="text-xl mr-1 font-medium opacity-70">${state.profile.currency}</span>
                ${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </h2>
        </div>
    `;
}

function renderTransactionRow(t) {
    const isIncome = t.type === 'INCOME';
    const amountColor = isIncome ? 'text-emerald-600' : 'text-slate-800';
    return `
        <div class="group flex items-center justify-between p-5 bg-white/40 rounded-3xl border border-white/60 hover:bg-white transition-all ios-button">
            <div class="flex items-center gap-5">
                <div class="w-12 h-12 rounded-2xl flex items-center justify-center ${isIncome ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}">
                    <svg class="w-5 h-5 ${isIncome ? '' : 'rotate-180'}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 17l-4 4m0 0l-4-4m4 4V3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5"/></svg>
                </div>
                <div>
                    <h4 class="font-bold text-slate-800 text-base leading-tight">${t.description}</h4>
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">${t.date}</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <p class="text-lg font-black tabular-nums tracking-tighter ${amountColor}">
                    ${isIncome ? '+' : '-'}${state.profile.currency}${t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                ${state.profile.role === 'ADMIN' ? `
                    <button data-id="${t.id}" class="btn-delete-tx p-2 text-slate-300 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100">
                        <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                    </button>
                ` : ''}
            </div>
        </div>
    `;
}

// --- EVENT HANDLERS ---
function handleFormSubmit(e) {
    e.preventDefault();
    // Cast elements to HTMLInputElement/HTMLSelectElement to access value
    const desc = (document.getElementById('tx-desc') as HTMLInputElement).value;
    const amount = parseFloat((document.getElementById('tx-amount') as HTMLInputElement).value);
    const type = (document.getElementById('tx-type') as HTMLSelectElement).value;
    if (!desc || isNaN(amount)) return;
    
    state.transactions.unshift({
        id: crypto.randomUUID(),
        description: desc,
        amount: amount,
        type: type,
        date: new Date().toISOString().split('T')[0]
    });
    saveState();
}

function handleLogin() {
    // Cast to HTMLInputElement to access value
    const id = (document.getElementById('login-id') as HTMLInputElement).value;
    const pass = (document.getElementById('login-pass') as HTMLInputElement).value;
    const err = document.getElementById('login-error');
    
    if (id === 'Arvin_Hanif' && pass === 'Arvin_Hanif') {
        state.profile.role = 'ADMIN';
        state.profile.name = 'Arvin Hanif';
        err.classList.add('hidden');
        closeLogin();
        saveState();
    } else {
        err.classList.remove('hidden');
    }
}

function handleLogout() {
    state.profile.role = 'USER';
    state.profile.name = 'User';
    closeProfile();
    saveState();
}

// --- MODAL CONTROLS ---
function openLogin() {
    document.getElementById('app-container').classList.add('modal-open');
    document.getElementById('modal-overlay').classList.replace('hidden', 'flex');
    document.getElementById('login-modal').classList.remove('hidden');
}

function closeLogin() {
    document.getElementById('app-container').classList.remove('modal-open');
    document.getElementById('modal-overlay').classList.replace('flex', 'hidden');
    document.getElementById('login-modal').classList.add('hidden');
}

function openProfile() {
    state.tempName = state.profile.name;
    // Cast to HTMLInputElement to access value
    (document.getElementById('input-temp-name') as HTMLInputElement).value = state.tempName;
    document.getElementById('app-container').classList.add('modal-open');
    document.getElementById('modal-overlay').classList.replace('hidden', 'flex');
    document.getElementById('profile-modal').classList.remove('hidden');
    render();
}

function closeProfile() {
    document.getElementById('app-container').classList.remove('modal-open');
    document.getElementById('modal-overlay').classList.replace('flex', 'hidden');
    document.getElementById('profile-modal').classList.add('hidden');
}

// --- INITIALIZATION ---
document.getElementById('btn-open-profile').addEventListener('click', openProfile);
document.getElementById('btn-close-profile').addEventListener('click', closeProfile);
document.getElementById('btn-close-login').addEventListener('click', closeLogin);
document.getElementById('btn-submit-login').addEventListener('click', handleLogin);

document.getElementById('input-temp-name').addEventListener('input', (e) => {
    // Cast target to HTMLInputElement to access value
    state.tempName = (e.target as HTMLInputElement).value;
    render();
});

document.querySelectorAll('.currency-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        state.profile.currency = btn.getAttribute('data-currency');
        render();
    });
});

document.getElementById('btn-save-profile').addEventListener('click', () => {
    state.profile.name = state.tempName || 'User';
    closeProfile();
    saveState();
});

// Initial Render
render();
